__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e60ef129113f6e24.js",
  "static/chunks/ed609b8e927efdc9.js",
  "static/chunks/turbopack-db0495b361786326.js"
])
